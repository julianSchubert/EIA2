interface PunktName {
    [key: string]: string;
}

interface Name {
    name: string;
    punktzahl: number;
}